import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import time
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from lifelines import KaplanMeierFitter
import requests
from bs4 import BeautifulSoup
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib



external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
server = app.server

### PART 1: SURVIVAL ANALYSIS PREP ###
df = pd.read_csv('df1_for_app.csv')
kmf1 = KaplanMeierFitter()

make_names = []
make_names.append('ALL MAKES')
make_names.append('LUXURY MAKES')
make_names.append('ECONOMY MAKES')
make_names.append('AMERICAN MAKES')
make_names.append('EUROPEAN MAKES')
make_names.append('JAPANESE MAKES')
for item in df.make.unique():
    make_names.append(item)
luxury_names = ['bentley', 'rolls-royce', 'maybach', 'bugatti', 'porsche', 'maserati', 'aston-martin', 'mclaren', 'alfa-romeo', 'lamborghini', 'mercedes-benz', 'bmw', 'cadillac', 'lexus', 'audi', 'volvo', 'jaguar', 'acura', 'lincoln', 'tesla']
japanese_names = ['toyota', 'mazda', 'subaru', 'honda', 'mitsubishi', 'suzuki', 'isuzu', 'acura', 'infiniti', 'scion', 'honda', 'lexus', 'nissan']
american_names = ['ford', 'chevrolet', 'jeep', 'gmc', 'buick', 'dodge', 'ram', 'cadillac', 'lincoln', 'chrysler', 'tesla', 'panoz', 'gm', 'mercury', 'pontiac', 'saturn', 'hummer', 'oldsmobile', 'plymouth', 'fisker']
euro_names = ['porsche', 'mercedes-benz', 'bmw', 'audi', 'volkswagen', 'volvo', 'opel', 'rolls-royce', 'bentley', 'aston-martin', 'mclaren', 'jaguar', 'mini', 'lamborghini', 'maserati', 'alfa-romeo', 'fiat', 'bugatti', 'renault', 'saab']


### PART 2: VALUE REGRESSION PREP
vr = pd.read_csv('prediction.csv')
vr = vr[['car', 'year', 'pred', 'perc']]
car_names = []
car_names.append('All Long-Running Cars')
for car in vr.car.unique():
    car_names.append(car)

### PART 3: CRV
crv_n = pd.read_csv('crv_rfc.csv')
crv_m = pd.read_csv('crv_rfc.csv', index_col=0)
labels = crv_m.pop('sold')
labels = labels.apply(lambda x: 1 if x==True else 0)
crv_m = pd.get_dummies(crv_m)

train, test, train_labels, test_labels = train_test_split(crv_m,
                                         labels,
                                         stratify = labels,
                                         test_size = 0.2,
                                         random_state = 100)
#train = train.fillna(train.mean())
#test = test.fillna(test.mean())
#model = RandomForestClassifier(n_estimators=150,
#                               min_samples_split=3,
#                               min_samples_leaf=1,
#                               random_state=100,
#                               max_features = 'sqrt',
#                               max_depth = 40,
#                               bootstrap=True,
#                               n_jobs=-1, verbose = 1)
#model.fit(train, train_labels)



filename = 'finalized_model.sav'
#joblib.dump(model, filename)
model = joblib.load(filename)

listing_dic = {}  # keep scraped data here
entries_completed = 0


for item in [12]:
    page_number = str(item)
    URL = 'https://www.truecar.com/used-cars-for-sale/listings/honda/cr-v/?page=' + page_number + '&sort[]=best_match'
    page = requests.get(URL)
    soup = BeautifulSoup(page.content, 'html.parser')
    main = soup.find(class_="row row-2 margin-bottom-3")

    try:
        listings = main.find_all('div', class_="card-content vehicle-card-body")

        for listing in listings:
            entries_completed += 1
            internal_dic = {}

            year = listing.find('span', class_="vehicle-card-year font-size-1")
            internal_dic['model_year'] = year.text

            make = listing.find('span', class_="vehicle-header-make-model text-truncate")
            internal_dic['make_model'] = make.text

            try:
                trim = listing.find('div', class_="font-size-1 text-truncate")
                internal_dic['trim'] = trim.text
            except AttributeError:
                print("no trim found for #", entries_completed)

            try:
                price_label = listing.find('span',
                                           class_="graph-icon-title margin-left-1 vehicle-card-price-rating-label text-truncate font-weight-bold")
                internal_dic['price_label'] = price_label.text
            except AttributeError:
                print("no price_label found for #", entries_completed)

            try:
                price = listing.find('h4', class_='heading-3 margin-y-1 font-weight-bold')
                internal_dic['price'] = price.text
            except AttributeError:
                print("no price found for #", entries_completed)

            try:
                mileage = listing.find('div', class_='d-flex w-100 justify-content-between')
                internal_dic['mileage'] = mileage.text  # CLEAN 'DISCOUNT AVAIL' PART OUT OF THIS
            except AttributeError:
                print("no mileage found for #", entries_completed)

            try:
                location = listing.find('div', class_='vehicle-card-location font-size-1 margin-top-1')
                internal_dic['location'] = location.text
            except AttributeError:
                print("no location found for #", entries_completed)

            try:
                color = listing.find('div', class_='vehicle-card-location font-size-1 margin-top-1 text-truncate')
                internal_dic['color'] = color.text
            except AttributeError:
                print("no color found for #", entries_completed)

            listing_dic[entries_completed] = internal_dic
    except AttributeError:
        continue
    time.sleep(0.05)

crv = pd.DataFrame.from_dict(listing_dic)
crv = crv.transpose()
crv['price'] = crv['price'].str.replace('$', '')
crv['mileage'] = crv['mileage'].str.replace('Discount Available', '')
crv['mileage'] = crv['mileage'].str.replace('Upfront Price Available', '')
crv['mileage'] = crv['mileage'].str.replace('miles', '')
crv['mileage'] = crv['mileage'].str.strip()
crv['city'] = crv['location'].str.split(',')
crv['city'] = crv['city'].apply(lambda x: x[0])
crv['city'] = crv['city'].str.replace(',', '')
crv['city'] = crv['city'].str.strip()
crv['state'] = crv['location'].str.split(',')
crv['state'] = crv['state'].apply(lambda x: x[1])
crv['state'] = crv['state'].str.replace(',', '')
crv['state'] = crv['state'].str.strip()
crv = crv.drop('location', 1)
crv['exterior_color'] = crv['color'].str.split(',')
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: x[0])
crv['exterior_color'] = crv['exterior_color'].str.replace('exterior', '')
crv['exterior_color'] = crv['exterior_color'].str.strip()
crv['trim'] = crv['trim'].apply(lambda x: None if 'Hybrid' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: None if 'Rear Entertainment' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'LX FWD' if 'LX 4WD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: None if 'EX 4WD Manual' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX FWD' if 'EX 4WD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX FWD' if 'EX FWD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'LX FWD' if 'LX FWD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'SE FWD' if 'SE 4WD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX-L FWD' if 'EX-L 4WD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX-L with Navigation FWD' if 'EX-L with Navigation 4WD' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX Special Edition FWD' if 'EX Special' in str(x) else x)
crv['trim'] = crv['trim'].apply(lambda x: 'EX FWD' if '4WD' in str(x) else x)
crv['drive'] = crv['trim']
crv['drive'] = crv['drive'].apply(lambda x: 'FWD' if 'FWD' in str(x) else ('AWD' if 'AWD' in str(x) else None))
crv['specs'] = crv['trim'].str.strip()
crv['specs'] = crv['specs'].apply(lambda x: 'EX-L with Nav' if 'EX-L with Nav' in str(x) else x)
crv['specs'] = crv['specs'].apply(lambda x: 'Touring' if 'Touring' in str(x) else x)
crv['specs'] = crv['specs'].apply(lambda x: 'SE' if 'SE' in str(x) else x)
crv['specs'] = crv['specs'].apply(lambda x: 'EX Special Edition' if 'EX Spe' in str(x) else x)
crv['specs'] = crv['specs'].apply(lambda x: 'EX-L' if str(x) == 'EX-L FWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: 'EX-L' if str(x) == 'EX-L AWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: 'EX' if str(x) == 'EX AWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: 'EX' if str(x) == 'EX FWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: 'LX' if str(x) == 'LX FWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: 'LX' if str(x) == 'LX AWD' else x)
crv['specs'] = crv['specs'].apply(lambda x: None if str(x) == '' else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Unknown' if 'Unknown' in str(x) else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Blue' if 'Purple' in str(x) else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Brown' if 'Copper' in str(x) else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Blue' if 'Teal' in str(x) else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Tan' if 'Beige' in str(x) else x)
crv['exterior_color'] = crv['exterior_color'].apply(lambda x: 'Tan' if 'Gold' in str(x) else x)
crv['price'] = crv['price'].str.replace(',', '')
crv['mileage'] = crv['mileage'].str.replace(',', '')
crv["price"] = pd.to_numeric(crv["price"])
crv["mileage"] = pd.to_numeric(crv["mileage"])
crv_raw = crv[['model_year', 'price', 'mileage', 'exterior_color', 'drive', 'specs', 'city', 'state']]
crv['ext_color'] = crv['exterior_color']
crv['common_color'] = crv.ext_color.apply(lambda x: True if x in (['Gray', 'Silver', 'White', 'Black']) else False)
crv['year_mean'] = crv.model_year.apply(lambda x: crv_n[crv_n['model_year'] == int(x)].price.mean())
crv['dev'] = (crv.price - crv.year_mean) / crv.year_mean
crv['ext_dev'] = (abs(crv['dev']) > 0.3)
crv['model_year'] = crv.model_year.apply(lambda x: int(x))
crv = crv[['model_year', 'price', 'mileage', 'specs', 'dev', 'ext_dev', 'common_color', 'ext_color']]
crv = pd.get_dummies(crv)
for col in crv_m.columns:
    if not col in crv.columns:
        crv[col] = 0

crv = crv.dropna()
predictions = model.predict_proba(crv)[:, 1]
results = pd.DataFrame(crv)
results['model_year'] = results['model_year'].apply(lambda x: str(x))
results['pred'] = predictions
results = results.merge(crv_raw, on = ['model_year', 'price', 'mileage'])
results = results[['pred', 'model_year', 'price', 'dev','mileage', 'specs', 'drive', 'exterior_color', 'city', 'state']]
results = results.sort_values(['pred'])
results['dev'] = results['dev'].apply(lambda x: str(round((100*x),4))+'%')
results = results[['model_year', 'price', 'dev', 'mileage', 'specs', 'drive', 'exterior_color', 'city', 'state']]
results.columns = ['Model Year', 'Price', 'Deviance From Model Year Avg. Price', 'Mileage', 'Configuration','Drive', 'Color', 'City', 'State']
unlikely = results[:5]
likely = results[-5:]



app.layout = html.Div([
    html.H1(children='Data Well Driven',
            style={
                'textAlign': 'center'}
            ),
    html.H3(children='An Exploration of Car Aging',
            style={
                'textAlign': 'center'}
            ),
    html.Div(
        [
        html.P('This is an exploration of various questions surrounding the popularity and reception of cars as they age, powered by web-scraped used car listings.'),
        ],
        id='intro', style={'padding-left': '50px'}
        ),
    html.Div(
        [
        html.P('For information on the statistics, machine learning, and code behind these analyses, visit acheevers.site !')
        ],
        id='intro_2', style={'padding-left': '50px', 'font-weight': 'bold'}
        ),
    html.H2(children='Part 1: How Long Will a Nameplate Last?'),
    html.Div(
        [
        html.P('Nameplates are the part of a car model\'s name that gets recycled every year, like Corvette or Camry. Long-lasting nameplates become a symbol of a car\'s success and cultural significance. ')
        ],
        id='survival-text', style={'padding-left': '50px'}
    ),
    html.Div(
        [
        html.P('Explore differences in nameplate survival by BRAND and BRAND TYPE using the menu below:')
        ],
        id='survival-text-2', style={'padding-left': '50px', 'font-weight': 'bold'}
    ),
    dcc.Dropdown(
        id='make-drop',
        options = [{'label':name.upper(), 'value':name} for name in make_names],
        value = ['ALL MAKES', 'honda'],
        multi = True,
        style={'padding-left': '25px'}
    ),
    dcc.Graph(id='graph-with-drop'),
    html.H2(children='Part 2: When Do Old Cars Become Cool Again?'),
    html.Div(
        [
        html.P('After a long enough period, some old cars are lucky enough to become classics.')
        ],
        id='regain-text', style={'padding-left': '50px'}),
    html.Div(
        [
            html.P('Explore WHEN various cars become classic using the menus below:')
        ],
        id='regain-text-2', style={'padding-left': '50px', 'font-weight': 'bold'}
    ),
    dcc.Dropdown(
        id='make-drop-2',
        options = [{'label':car, 'value':car} for car in car_names],
        value = ['Chevrolet Corvette'],
        multi = True,
        style={'padding-left': '25px'}
    ),
    dcc.RadioItems(id = 'radio-item',
        options=[
            {'label': 'Predicted Value in $     ', 'value': 'pred'},
            {'label': 'Predicted Value in Percent of 2020 Value', 'value': 'perc'}
        ],
        value='pred',
        labelStyle={'display': 'inline-block'},
        style={'padding-left': '25px'}
    ),
    dcc.Graph(id='graph-with-drop-2'),
    html.H2(children='Part 3: What Makes a Used Car Desirable?'),
    html.Div(
        [
            html.P('The Honda CR-V is America\'s most popular used SUV. Which used CR-Vs are \'hot\'? What do fast-selling (or slow-selling) used cars have in common?')
        ],
        id='crv-text', style={'padding-left': '50px'}
    ),
    html.Div(
        [
            html.P('Explore \'HOT\' and \'NOT\' CR-V picks from a randomly sampled collection of CR-V for sale today:')
        ],
        id='crv-text-2', style={'padding-left': '50px', 'font-weight': 'bold'}
    ),
    html.Div(
        [
        html.P('HOT: Most Likely To Sell Quickly')
        ],
        id='crv-data-1', style={'padding-left': '50px'}
    ),
    dash_table.DataTable(
        id='table_1',
        columns=[{"name": i, "id": i} for i in likely.columns],
        data=likely.to_dict('records')),
    html.Div(
        [
            html.P('NOT: Least Likely To Sell Quickly')
        ],
        id='crv-data-2', style={'padding-left': '50px'}
    ),
    dash_table.DataTable(
        id='table_2',
        columns=[{"name": i, "id": i} for i in unlikely.columns],
        data=unlikely.to_dict('records'))
])

@app.callback(
    Output('graph-with-drop', 'figure'),
    [Input('make-drop', 'value')])
def update_figure(selected_make):
    selecteds = {}

    for selected in selected_make:

        if selected == 'ALL MAKES':
            filtered_df = df
        elif selected == 'LUXURY MAKES':
            filtered_df = df[df['make'].isin(luxury_names)]
        elif selected == 'ECONOMY MAKES':
            filtered_df = df[~df['make'].isin(luxury_names)]
        elif selected == 'AMERICAN MAKES':
            filtered_df = df[df['make'].isin(american_names)]
        elif selected == 'EUROPEAN MAKES':
            filtered_df = df[df['make'].isin(euro_names)]
        elif selected == 'JAPANESE MAKES':
            filtered_df = df[df['make'].isin(japanese_names)]
        else:
            filtered_df = df[df['make'] == selected]

        kmf1.fit(durations = filtered_df.duration, event_observed = filtered_df.death)
        df_filtered_graph = pd.DataFrame(kmf1.predict(range(0,22)))
        df_filtered_graph['selected_make'] = selected
        selecteds[selected] = df_filtered_graph

    fig = go.Figure()
    fig.update_layout(legend=dict(y=0.5, traceorder='reversed', font_size=16, yanchor="top", xanchor="left"))

    for key in selecteds:
        graph_df = selecteds[key]
        fig.add_trace(go.Scatter(x=graph_df.index, y=graph_df.KM_estimate, name=key.upper(), line_shape='hv'))

    fig.update_layout(title="Nameplate Kaplan-Meier Survival Probablity By Brand", xaxis_title="Years", yaxis_title="Probability", legend_title="Selected Makes")

    fig.update_layout(transition_duration=500)

    return fig
@app.callback(
    Output('graph-with-drop-2', 'figure'),
    [Input('make-drop-2', 'value'), Input('radio-item', 'value')])
def update_figure(selected_make2, selected_radio):
    selecteds2 = []

    for selected in selected_make2:
        if selected == 'All Long-Running Cars':
            filtered_df = vr
        else:
            filtered_df = vr[vr['car'] == selected]

        selecteds2.append(filtered_df)
        combined_df = pd.concat(selecteds2)

    if selected_radio == 'pred':
        fig2 = px.line(combined_df, x='year', y='pred', color = 'car', title = 'Predicted Value by Year',
            labels={
                 "year": "Year",
                 "perc": "Percent of 2020 Value",
                 "pred": "Predicted Value ($)",
                 "car": "Cars"
                 })
    else:
        fig2 = px.line(combined_df, x='year', y='perc', color = 'car', title = 'Predicted Value by Year',
        labels={
                     "year": "Year",
                     "perc": "Percent of 2020 Value",
                     "pred": "Predicted Value ($)",
                     "car": "Cars"
                 })

    fig2.update_layout(transition_duration=500)

    return fig2


if __name__ == '__main__':
    app.run_server(debug=False)
